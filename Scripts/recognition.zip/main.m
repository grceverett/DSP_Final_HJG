function main
    % Define samples
    [nomTrain, nomVal, nomTest, intVal, intTest] = getFiles;
    
    % List nominal & intruder speakers
    printSpeakers(nomTest, intTest)

    %% Extract features | Output is array of data from windows
    % Nominal Train | Nominal Val | Intruder Val
    [nomTrainFeatures, nomTrainLabels]  = extractFeatures(nomTrain);
    [nomValFeatures, nomValLabels]      = extractFeatures(nomVal);
    [intValFeatures, intValLabels]    = extractFeatures(intVal);

    % Train model   --- TODO
    trainFeatures(nomTrainFeatures, nomTrainLabels, nomValFeatures, nomValLabels, intValFeatures, intValLabels);
    
    % Test model    --- TODO